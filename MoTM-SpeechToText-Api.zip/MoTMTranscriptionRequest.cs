﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace MoTM_SpeechToText_Api
{
    class MoTMTranscriptionRequest
    {
        [JsonPropertyName("audio_url")]
        public string AudioUrl { get; set; }
        [JsonPropertyName("auto_chapters")]
        public string AutoChapter { get; set; }
      
    }
}
