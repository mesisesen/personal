﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace MoTM_SpeechToText_Api
{
    class Program
    {
        
        static void Main(string[] args)
        {

             //Starts instance of Recording
            AudioRecorder audioRecorder = new AudioRecorder();
            Console.Write("Start Recording? (Y/N)");
            string start = Console.ReadLine();
            
            if (start.ToLower() == "y")
            {

                //Starts Recording 
                audioRecorder.instantiateRecorder();
            }
            while (true) {
                Console.Write("Stop Recording? (Y/N)");
                string end = Console.ReadLine();
                if (end.ToLower() == "y")
                {
                    // Stops Recording
                    audioRecorder.stopRecording();
                    break;
                }
            }


            //After recording, app will submit request to assembly AI by uploading the audio file into v2/upload
            PerformTranscription transcription = new PerformTranscription();
            transcription.setAudioFilePath(audioRecorder.getoutputFileName());
            transcription.doTranscription();

        }


    }



    }
