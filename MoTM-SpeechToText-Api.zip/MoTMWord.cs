﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace MoTM_SpeechToText_Api
{
    class MoTMWord
    {
        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }

        [JsonPropertyName("end")]
        public int End { get; set; }

        [JsonPropertyName("start")]
        public int Start { get; set; }

        [JsonPropertyName("text")]
        public string Text { get; set; }
        [JsonPropertyName("speaker")]
        public string speaker { get; set; }

    }
}
