﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace MoTM_SpeechToText_Api
{
    class MoTMChapter
    {
        [JsonPropertyName("headline")]
        public string headline { get; set; }
        [JsonPropertyName("summary")]
        public string Summary { get; set; }
    }
}
