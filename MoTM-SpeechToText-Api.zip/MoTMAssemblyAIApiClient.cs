﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;


namespace MoTM_SpeechToText_Api
{
    class MoTMAssemblyAIApiClient
    {
        private readonly string _apiToken;
        private readonly string _baseUrl;
        private readonly HttpClient _httpClient;

        public MoTMAssemblyAIApiClient(string apiToken, string baseUrl)
        {
            _apiToken = apiToken;
            _baseUrl = baseUrl;
            _httpClient = new HttpClient() { BaseAddress = new Uri(_baseUrl) };
            _httpClient.DefaultRequestHeaders.Add("Authorization", _apiToken);
        }
        private async Task<TModel> SendRequestAsync<TModel>(HttpRequestMessage request)
        {
            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();
            var json = await response.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<TModel>(json);
        }
        public Task<MoTMUploadAudioResponse> UploadFileAsync(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException(filePath);
            }

            var request = new HttpRequestMessage(HttpMethod.Post, "v2/upload");
            request.Headers.Add("Transer-Encoding", "chunked");

            var fileReader = File.OpenRead(filePath);
            request.Content = new StreamContent(fileReader);

            return SendRequestAsync<MoTMUploadAudioResponse>(request);
        }
        public Task<MoTMTranscriptionResponse> SubmitAudioFileAsync(string audioUrl)
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "v2/transcript");
            var requestBody = JsonSerializer.Serialize(new MoTMTranscriptionRequest { AudioUrl = audioUrl, AutoChapter = "true"});
            request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");

            return SendRequestAsync<MoTMTranscriptionResponse>(request);
        }
        public Task<MoTMTranscriptionResponse> GetTranscriptionAsync(string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"v2/transcript/{id}");

            return SendRequestAsync<MoTMTranscriptionResponse>(request);
        }
        public Task<MoTMTranscriptionResponseSentence> GetTranscriptionAsyncSentence(string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"v2/transcript/{id}/sentences");
            return SendRequestAsync<MoTMTranscriptionResponseSentence>(request);
        }
    }
}
