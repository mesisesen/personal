﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace MoTM_SpeechToText_Api
{
    class MoTMSentence
    {

        [JsonPropertyName("confidence")]
        public double? Confidence { get; set; }

        [JsonPropertyName("end")]
        public int? End { get; set; }

        [JsonPropertyName("start")]
        public int? Start { get; set; }

        [JsonPropertyName("text")]
        public string text { get; set; }

        [JsonPropertyName("words")]
        public List<MoTMWord> Words { get; set; }





    }
}
