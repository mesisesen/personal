﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace MoTM_SpeechToText_Api
{
    class MoTMTranscriptionResponseSentence
    {

        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("confidence")]
        public double? confidence { get; set; }

        [JsonPropertyName("audio_duration")]
        public double? audio_duration { get; set; }


        [JsonPropertyName("sentences")]
        public List<MoTMSentence> Sentence { get; set; }
       

    }
}
