﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MoTM_SpeechToText_Api
{
    class Configurations
    {
        private const string API_KEY = "TYPE YOUR APIKEY HERE";
        private const string API_URL = "https://api.assemblyai.com/";
        // relative or absolute file path
       // private const string AUDIO_FILE_PATH = @"./audio/audiowithvoice4.m4a";

        public Configurations()
        {

        }

        public string getAPIKEY() {
            return API_KEY;
        }
        public string getAPIUrl() {
            return API_URL;
        }
       
    }
}
