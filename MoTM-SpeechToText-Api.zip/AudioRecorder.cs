﻿using System;
using System.Collections.Generic;
using System.Text;
using NAudio.Wave;
using System.IO;
using System.Diagnostics;


namespace MoTM_SpeechToText_Api
{

 
    class AudioRecorder
    {
        private string outputFilename;
        private WasapiLoopbackCapture capture;


        public AudioRecorder() { 
        
        }
        public string getoutputFileName() {
            return outputFilename;
        }
        public void instantiateRecorder() {
            try
            {
                Directory.CreateDirectory("Recorded Audio");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            string filename = "Recorded Audio/MoTM Audio " + DateTime.Now.ToString("Mdyhhmmss") + ".wav";
            this.setOutputFilename(filename);
            startRecording();
        }
        public void setOutputFilename(string outputfilename) {
            this.outputFilename = outputfilename;
        }
        public void startRecording() {
            Console.WriteLine("Recording started");
            
            
            capture = new WasapiLoopbackCapture();
            var writer = new WaveFileWriter(outputFilename, capture.WaveFormat);
            capture.DataAvailable += async (s, e) =>
            {
                if (writer != null)
                {
                    await writer.WriteAsync(e.Buffer, 0, e.BytesRecorded);
                    await writer.FlushAsync();

                }



            };
            capture.RecordingStopped += (s, e) =>
            {
                if (writer != null) {
                    writer.Dispose();
                    writer = null;

                }
                capture.Dispose();
            };
            capture.StartRecording();
        }


        public void stopRecording() {
            capture.StopRecording();
            if (outputFilename == null)
            {
                return;
            }
            Console.WriteLine("Recording finished.");
        }
    }
}
