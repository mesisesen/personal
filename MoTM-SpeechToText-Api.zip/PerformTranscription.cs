﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.Text.Json.Serialization;
using System.Text.Json;
using Newtonsoft.Json.Linq;

using System.Net.Http;

using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace MoTM_SpeechToText_Api
{

    class PerformTranscription
    {
        private String AUDIO_FILE_PATH;
        private String filePath;
        public PerformTranscription() { 
        
        }

        public string getFilePath()
        {

            return filePath;
        }
        public void setAudioFilePath(string path) {
            AUDIO_FILE_PATH = @"./" + path;
        }
        public void doTranscription() {
            Configurations config = new Configurations();

            string API_KEY = config.getAPIKEY();
            string API_URL = config.getAPIUrl();
           // string AUDIO_FILE_PATH = config.getAudioFilePath();
           
            var client = new MoTMAssemblyAIApiClient(API_KEY, API_URL);
            var client2 = new MoTMAssemblyAIApiClient(API_KEY, API_URL);
            // Upload file
            var uploadResult = client.UploadFileAsync(AUDIO_FILE_PATH).GetAwaiter().GetResult();

            // Submit file for transcription
            var submissionResult = client.SubmitAudioFileAsync(uploadResult.UploadUrl).GetAwaiter().GetResult();
            Console.WriteLine($"File {submissionResult.Id} in status {submissionResult.Status}");

            //Query status of transcription until it's `completed`
            MoTMTranscriptionResponse result = client.GetTranscriptionAsync(submissionResult.Id).GetAwaiter().GetResult();
          
            while (!result.Status.Equals("completed"))
            {
               
                    //Console.WriteLine($"File {result.Id} in status {result.Status}");
                   
                Thread.Sleep(1000);
                result = client.GetTranscriptionAsync(submissionResult.Id).GetAwaiter().GetResult();
            }

            Console.WriteLine("Transcription in progress..");
            MoTMTranscriptionResponse resultChapter = client.GetTranscriptionAsync(submissionResult.Id).GetAwaiter().GetResult();
            // MoTMTranscriptionResponseSentence resultSentence = client.GetTranscriptionAsyncSentence(submissionResult.Id).GetAwaiter().GetResult();
            // Perform post-procesing with the result of the transcription
            //Console.WriteLine($"File {result.Id} in status {resultSentence.Status}");
            // Console.WriteLine($"{resultSentence.Sentence?.Count} words transcribed.");
            try
            {
                Directory.CreateDirectory("Transcriptions");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //bool isAdding = false;
            filePath = "Transcriptions/MoTM File " + DateTime.Now.ToString("Mdyhhmmss") + ".txt";
            using (StreamWriter outputFile = new StreamWriter(filePath))
            {

             
                //Start Chapter code
                outputFile.WriteLine($"Notes/Action Items/Summary:");
                foreach (var word in resultChapter.Chapters)
                {
                    outputFile.WriteLine($"Notes / Action : {word.headline}");
                    outputFile.WriteLine($"Item / Summary : {word.Summary}");

                    //Console.WriteLine($"Word: '{word.text}'")

                }
                //end Chapter Code

            }
            //Console.WriteLine("Transcription Completed" );


            using (var clientUpload = new HttpClient()) { 
                var endpoint = new Uri("http://localhost:8081/upload/"+submissionResult.Id);
                var resultUploaded = clientUpload.GetAsync(endpoint).Result;
                 var jsonUploaded = resultUploaded.Content.ReadAsStringAsync().Result;
                Console.WriteLine(jsonUploaded.ToString()); 


            }
            // Console.ReadLine();

        }
    }
}
